package com.example.sqlitedatabase

import android.annotation.SuppressLint
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.sqlitedatabase.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        var binding: ActivityMainBinding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        var g :String? = null
        var city :String? = null

        binding.txtGender.setOnCheckedChangeListener { group, checkedId ->
            g = if (R.id.male == checkedId) "Male" else "Female"
        }

        binding.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                city = parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

        fun getSubjects(subject1:CheckBox,subject2:CheckBox,subject3:CheckBox):String{
            var subject = ""
            if (subject1.isChecked){
                subject += subject1.text.toString()
            }
            if (subject2.isChecked){
                subject += ","+subject2.text.toString()
            }
            if (subject3.isChecked){
                subject += ","+subject3.text.toString()
            }
            return subject
        }

        binding.btnSave.setOnClickListener {

            val db = DBHelper(this, null)

            val name = binding.txtName.text.toString()
            val email = binding.txtEmail.text.toString()
            val gender = g.toString()
            val city = city.toString()
            val course = getSubjects(binding.subject1,binding.subject2,binding.subject3)


            db.addData(name, email, gender, city, course)

            Toast.makeText(applicationContext,"Add Data in Database",Toast.LENGTH_LONG).show()

            binding.txtName.text.clear()
            binding.txtEmail.text.clear()
            binding.txtGender.clearCheck()

        }

        binding.btnDisplay.setOnClickListener {
            val db = DBHelper(this,null)

            val cursor = db.getData()

            if(cursor != null) {
                if (cursor.moveToFirst())
                {
                    binding.addData.removeAllViews()
                    do {
                        var txtStudentsData:TextView = TextView(applicationContext)
                        txtStudentsData.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20F)
                        txtStudentsData.text = cursor.getString(cursor.getColumnIndex(DBHelper.ID_COL))+" " +
                                cursor.getString(cursor.getColumnIndex(DBHelper.NAME_COL)) +" "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.EMAIL_COL)) +" "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.GENDER_COL)) +" "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.CITY_COL)) +" "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.COURSE_COL))

                        binding.addData.addView(txtStudentsData)

                    } while (cursor.moveToNext())
                }

                // at last we close our cursor
                cursor.close()
            }else {
                Toast.makeText(applicationContext,"No Data Found",Toast.LENGTH_LONG).show()
            }
        }

        binding.btnUpdate.setOnClickListener {
            val db = DBHelper(this,null)

            val id = binding.txtSearch.text.toString().toInt()
            val name = binding.txtName.text.toString()
            val email = binding.txtEmail.text.toString()
            val gender = g.toString()
            val city = city.toString()
            val course = getSubjects(binding.subject1,binding.subject2,binding.subject3)

            db.updateData(id,name, email, gender, city, course)

            val cursor = db.getData()

            if(cursor != null) {
                if (cursor.moveToFirst())
                {
                    binding.addData.removeAllViews()
                    do {
                        var txtStudentsData:TextView = TextView(applicationContext)
                        txtStudentsData.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20F)
                        txtStudentsData.text = cursor.getString(cursor.getColumnIndex(DBHelper.ID_COL))+", " +
                                cursor.getString(cursor.getColumnIndex(DBHelper.NAME_COL)) +", "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.EMAIL_COL)) +", "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.GENDER_COL)) +", "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.CITY_COL)) +", "+
                                cursor.getString(cursor.getColumnIndex(DBHelper.COURSE_COL))

                        binding.addData.addView(txtStudentsData)

                    } while (cursor.moveToNext())
                }

                // at last we close our cursor
                cursor.close()
            }else {
                Toast.makeText(applicationContext,"No Data Found",Toast.LENGTH_LONG).show()
            }

        }

        binding.btnDeleteAll.setOnClickListener {
            val db = DBHelper(this,null)

            db.deleteAllData()

            Toast.makeText(applicationContext,"Data Deleted Successfully.",Toast.LENGTH_LONG).show()
        }

        binding.btnDeleteById.setOnClickListener {
            val db = DBHelper(this,null)

            val id = binding.txtSearch.text.toString().toInt()

            db.deleteByIdData(id)

        }
    }
}