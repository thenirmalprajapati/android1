package com.example.sqlitedatabase

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DBHelper(context: Context, factory:SQLiteDatabase.CursorFactory?):
    SQLiteOpenHelper(context,DATABASE_NAME,factory,DATABASE_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        val query = ("CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                NAME_COL + " TEXT," +
                EMAIL_COL + " TEXT," +
                GENDER_COL + " TEXT," +
                CITY_COL + " TEXT," +
                COURSE_COL + " TEXT" +
                ")")

        db.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    fun addData(name:String,email:String,gender:String,city:String,course:String)
    {
        val values = ContentValues()

        values.put(NAME_COL,name)
        values.put(EMAIL_COL,email)
        values.put(GENDER_COL,gender)
        values.put(CITY_COL,city)
        values.put(COURSE_COL,course)

        val db = this.writableDatabase

        db.insert(TABLE_NAME,null,values)

        db.close()
    }

    fun getData(): Cursor?
    {
        val db = this.readableDatabase

        return db.rawQuery("SELECT * FROM $TABLE_NAME", null)
    }

    fun updateData(id:Int, name:String,email:String,gender:String,city:String,course:String)
    {
        val values = ContentValues()

        values.put(NAME_COL,name)
        values.put(EMAIL_COL,email)
        values.put(GENDER_COL,gender)
        values.put(CITY_COL,city)
        values.put(COURSE_COL,course)

        val db = this.writableDatabase

        db.update(TABLE_NAME,values,"id=?", arrayOf(id.toString()))

        db.close()
    }

    fun deleteAllData()
    {
        val db = this.writableDatabase

        db.delete(TABLE_NAME,null,null)

        db.close()
    }

    fun deleteByIdData(id:Int)
    {
        val db = this.writableDatabase

        db.delete(TABLE_NAME,"id=?", arrayOf(id.toString()))

        db.close()
    }

    companion object {
        // below is variable for database name
        private const val DATABASE_NAME = "DEMO_DB"

        // below is the variable for database version
        private const val DATABASE_VERSION = 1

        private const val TABLE_NAME = "emp"
        const val ID_COL = "id"
        const val NAME_COL = "name"
        const val EMAIL_COL = "email"
        const val GENDER_COL = "gender"
        const val CITY_COL = "city"
        const val COURSE_COL = "course"
    }
}